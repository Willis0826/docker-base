
Fields of constructed types
---------------------------

.. toctree::
   :maxdepth: 2

   /docs/type/namedtype/namedtype
   /docs/type/namedtype/optionalnamedtype
   /docs/type/namedtype/defaultednamedtype
   /docs/type/namedtype/namedtypes
